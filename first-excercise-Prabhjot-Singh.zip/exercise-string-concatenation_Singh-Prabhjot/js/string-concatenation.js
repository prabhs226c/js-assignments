'use strict';

const NAME = 'Reza';
const AGE = 54;
const YEAR = 2020;

console.log(NAME + ': ' + AGE);

console.log(NAME , AGE);
console.log(NAME+AGE)
console.log(YEAR+AGE)
console.log(NAME+AGE+YEAR)
console.log(AGE+NAME+YEAR)