'use strict'

const temperature = 21.3
const fruits = ['apple', 'pear', 'orange']
const eighteen = 18
const isTrue  = true
const isNull = null
let ghostVariable

console.log('Yo.')
console.log(temperature)
console.log('['+fruits+']')
console.log('The temperature is',temperature)
console.log('The Collection of Fruits is ['+fruits+']')
console.log('<h1>No HTML Interpreter</h1>')
console.log(eighteen+' eighteen',isTrue,isNull,ghostVariable)
console.log(('This is a group (closed by default)\n'),'group content')
console.log(('This is a second group\n'),'content of the second group')

